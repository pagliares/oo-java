package hostelapp;

public class AuthorizationVISA implements Authorization {

	@Override
	public boolean authorize() {
		// complex code to communicate with VISA issuer
		return true;
	}

}
