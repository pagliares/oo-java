package hostelapp;

public class Report {
	private Payment [] payments;
	private int contador;
	
	public Report() {
		payments = new Payment[2];
		contador = 0;
	}
	
	public void add(Payment payment) {
		payments[contador] = payment;
		contador++;
	}
	
	@Override
	public String toString() {
		String temp = "";
	    for (Payment x: payments)
	    	temp+=x.toString() + "\n";
	    return temp;
 	}
	
	public static void main(String[] args) {
		Report report = new Report();
		Payment pCC = new Payment(200.00);
		pCC.setPaymentType(new CreditCardPayment("VISA", "123-1234-12345-12",  "Florentino Ariza"));
		
		report.add(pCC);
		
		Payment pDC = new Payment(500.50);
		pDC.setPaymentType(new DebtCardPayment("Wells Fargo", "8979.1234.123-12", "Florentino Ariza" ));
		report.add(pDC);
		
		System.out.println("Payment report");
		System.out.println(report.toString());
		
	}

}
