package hostelapp;

public class AuthorizationMasterCard  implements Authorization {
	@Override
	public boolean authorize() {
		// complex code to communicate with MasterCard issuer
		return true;
	}

}
