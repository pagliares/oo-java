package hostelapp;

import java.time.LocalDateTime;

public class Payment extends Expense implements Processable {
 	private PaymentType paymentType;
 	private LocalDateTime localDateTime;
	
	public Payment(double amount) {
		super(amount);
	}

	public PaymentType getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(PaymentType paymentType) {
		this.paymentType = paymentType;
	}
	
	@Override
    public String toString() { 
		return  paymentType.toString();
	}

	@Override
	public LocalDateTime getTime() {
		this.localDateTime = LocalDateTime.now();
		return  localDateTime; // current date and time
	}

	@Override
	public void process() {
	     System.out.println("Processing the payment");
	     System.out.println(paymentType);
		
	}
}
