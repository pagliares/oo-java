package hostelapp;

public interface Authorization {
	public abstract boolean authorize();  // public abstract - before Java SE 8

}
