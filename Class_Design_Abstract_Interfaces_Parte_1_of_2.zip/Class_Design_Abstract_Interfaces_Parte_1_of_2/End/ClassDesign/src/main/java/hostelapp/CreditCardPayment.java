package hostelapp;

import java.time.LocalDate;

public class CreditCardPayment extends CardPayment {
    
	private  String issuer;
	private LocalDate expirationDate;
	private String securityCode;
	 
	public CreditCardPayment(String issuer, String cardNumber, String nameOnCard) {
		super("Credit Card Payment", cardNumber, nameOnCard);
		this.issuer = issuer;
	}

	public String getIssuer() {
		return issuer;
	}
	
	public void setIssuer(String issuer) {
		this.issuer = issuer;
 	}
	
	@Override
	public boolean equals(Object object) {
		CreditCardPayment  ccp = null;
		if (object instanceof CreditCardPayment ) {
			ccp = (CreditCardPayment) object;
            if (ccp.getCardNumber().equals(this.getCardNumber())) {
            	return true;
            }
 		} else {
 			return false;
 		}
		return false;
	}
	
	public LocalDate getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(LocalDate expirationDate) {
		this.expirationDate = expirationDate;
	}

	public String getSecurityCode() {
		return securityCode;
	}

	public void setSecurityCode(String securityCode) {
		this.securityCode = securityCode;
	}	
	
	public String toString() {
		String temp = "Payment details (credit card):\n" +  
	                             super.toString() + "\n" +
 	                              "Issuer...:"+ this.issuer + "\n";    
		return temp;
	}

 }
