package hostelapp;

public interface Processable {
	public abstract void process();

}
