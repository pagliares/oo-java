package hostelapp;

public abstract class PaymentType {
	private String type;
	
	public PaymentType(String type) {
		// super()
		this.type = type;
	}
	
	public String getType() {
		return type;
	}

	@Override
    public String toString() { 
		return "Payment type..: " + type;
	}

}
