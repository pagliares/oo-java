package hostelapp;

public class CashPayment extends PaymentType {
	public double amountTendered;
	
	public CashPayment(double amountTendered) {
		super("Cash Payment");
		this.amountTendered = amountTendered;
	}
 
	public double getAmountTendered() {
		return amountTendered;
	}

	public void setAmountTendered(double amountTendered) {
		this.amountTendered = amountTendered;
	}
	
	@Override
 	public String toString() {
		String temp =  "Total amount...: $ "+ this.getType()   + "\n" +
	                              "Amount Tendered...: $"+ this.amountTendered  + "\n";                
		return temp;
	}
}
