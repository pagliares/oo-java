package hostelapp;
public class PaymentTest {
	
	public static void main(String[] args) {
		PaymentTest pt = new PaymentTest();
		
		Payment paymentCC = new Payment(500.00);
		PaymentType ccp = new CreditCardPayment("VISA", "123-1234-12345-12",  "Florentino Ariza");
        paymentCC.setPaymentType(ccp);
		
		 pt.processPayment(paymentCC);
		
		Payment paymentDC = new Payment(200.50);
		DebtCardPayment dcp = new DebtCardPayment("Wells Fargo", "8979.1234.123-12", "Florentino Ariza" );
		paymentDC.setPaymentType(dcp);
	   
		pt.processPayment(paymentDC);
	    
		Payment paymentCash= new Payment(100);
	    CashPayment cash = new CashPayment(200);
	    paymentCash.setPaymentType(cash);
	   
	    pt.processPayment(paymentCash);
	    
	    Payment paymentCheck = new Payment(500);
	    PaymentType check = new CheckPayment("B01", "Wells Fargo", 10);
	    paymentCheck.setPaymentType(check);
	    
	    pt.processPayment(paymentCheck);
   	}
	
	public void processPayment(Payment cp) {
		System.out.println("Processing the payment");
        System.out.println(cp);
	}
}
